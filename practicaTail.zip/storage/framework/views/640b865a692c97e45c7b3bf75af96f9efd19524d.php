<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
  <title><?php echo $__env->yieldContent('titulo'); ?></title>
</head>
<body class="bg-gray-100">
<header class="p-5 border-b bg-white shadow">
  <div class="container mx-auto flex justify-between p-2">
     <h1 class="text-3xl font-black">
        Practica con Tailwind
     </h1>
     <nav class="flex gap-2 items-center">
      <a class="font-bold uppercase text-gray-600 text-sm" href="#">
         Login
      </a>
      <a class="font-bold uppercase text-gray-600 text-sm" href="#">
        Crear Cuenta
     </a>
     </nav>
  </div>
</header>
  <?php echo $__env->yieldContent('contenido'); ?>
</body>
</html><?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>