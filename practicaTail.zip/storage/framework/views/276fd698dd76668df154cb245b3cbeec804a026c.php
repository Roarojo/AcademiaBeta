<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>
  <h1 class="text-sky-400">
    Hola mundo
  </h1>
  <h2 class="text-gray-400 text-4xl">
    Adios Mundo
  </h2>
</body>
</html><?php /**PATH /var/www/html/resources/views/app.blade.php ENDPATH**/ ?>